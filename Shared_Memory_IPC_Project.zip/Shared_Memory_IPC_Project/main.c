#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sched.h>
#include "shared.h"

int main(void) {
    int id = shmget(IPC_PRIVATE, sizeof(SharedData), IPC_CREAT | 0600);
    if (id == -1) { perror("shmget"); return 1; }

    SharedData *data = shmat(id, NULL, 0);
    if (data == (void *)-1) { perror("shmat"); shmctl(id, IPC_RMID, NULL); return 1; }

    data->ready = 0;
    data->message[0] = '\0';

    pid_t pid = fork();
    if (pid == -1) { perror("fork"); shmdt(data); shmctl(id, IPC_RMID, NULL); return 1; }

    if (pid == 0) {
        while (!data->ready) sched_yield();
        printf("Child received: %s\n", data->message);
        data->ready = 2;
        shmdt(data);
        exit(0);
    } else {
        snprintf(data->message, sizeof(data->message), "Hello from the parent process!");
        data->ready = 1;
        while (data->ready != 2) sched_yield();
        printf("Parent: message exchange completed.\n");
        waitpid(pid, NULL, 0);
    }

    shmdt(data);
    shmctl(id, IPC_RMID, NULL);
    return 0;
}
